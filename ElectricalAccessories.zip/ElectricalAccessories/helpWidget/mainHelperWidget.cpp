﻿#include "mainHelperWidget.h"

mainHelperWidget::mainHelperWidget(QWidget *parent)
    : QWidget(parent)
{

}
