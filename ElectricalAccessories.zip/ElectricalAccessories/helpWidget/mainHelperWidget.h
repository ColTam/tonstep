﻿#ifndef MAINHELPERWIDGET_H
#define MAINHELPERWIDGET_H

#include <QWidget>

class mainHelperWidget : public QWidget
{
    Q_OBJECT
public:
    explicit mainHelperWidget(QWidget *parent = 0);
    ~mainHelperWidget();

signals:

public slots:
};

#endif // MAINHELPERWIDGET_H
